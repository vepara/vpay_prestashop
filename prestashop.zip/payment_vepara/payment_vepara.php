<?php

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;
require_once  dirname(__FILE__) . '/classes/Vepara.php';
if (!defined('_PS_VERSION_')) {
    exit;
}

class payment_vepara extends PaymentModule
{
    protected $_html = '';
    protected $_postErrors = array();

    public $details;
    public $owner;
    public $address;
    public $extra_mail_vars;

    public function __construct()
    {
        $this->name = 'payment_vepara';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->ps_versions_compliancy = array('min' => '1.7');
        $this->author = 'magento-tr';
        $this->controllers = array('validation', 'payment', "installment", "d3Start");
        $this->is_eu_compatible = 1;

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('Vepara Öde');
        $this->description = $this->l('Accept Credit Card Payments Via Vepara');

        if (!count(Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->l('No currency has been set for this module.');
        }

        $this->checkAndSetCookieSameSite();
    }
    protected function _postProcess()
    {
        if (Tools::isSubmit('btnSubmit')) {
            Configuration::updateValue('payment_vepara_merchant_id', Tools::getValue('payment_vepara_merchant_id'));
            Configuration::updateValue('payment_vepara_merchant_key', Tools::getValue('payment_vepara_merchant_key'));
            Configuration::updateValue('payment_vepara_app_key', Tools::getValue('payment_vepara_app_key'));
            Configuration::updateValue('payment_vepara_app_secret', Tools::getValue('payment_vepara_app_secret'));
            Configuration::updateValue('payment_vepara_3d_option', Tools::getValue('payment_vepara_3d_option'));
            Configuration::updateValue('payment_vepara_env', Tools::getValue('payment_vepara_env'));
            Configuration::updateValue('payment_vepara_form_turu', Tools::getValue('payment_vepara_form_turu'));
        }
        $this->_html .= $this->displayConfirmation($this->l('Settings updated'));
    }
    public function getContent()
    {
        if (Tools::isSubmit('btnSubmit')) {
            //$this->_postValidation();
            if (!count($this->_postErrors))
                $this->_postProcess();
            else
                foreach ($this->_postErrors as $err)
                    $this->_html .= $this->displayError($err);
        } else
            $this->_html .= '<br />';

        $this->_html .= $this->_displayInfo();
        $this->_html .= $this->renderForm();

        return $this->_html;
    }

    protected function _displayInfo()
    {
        //return $this->display(__FILE__, 'infos.tpl');
        return "";
    }

    /*
     * Admin Panelindeki Yönetici Ayarları Formu
     */
    public function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Vepara Parameters'),
                    'icon' => 'icon-envelope'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('Merchant ID'),
                        'name' => 'payment_vepara_merchant_id',
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Merchant Key'),
                        'name' => 'payment_vepara_merchant_key',
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('App Key'),
                        'name' => 'payment_vepara_app_key',
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('App Secret'),
                        'name' => 'payment_vepara_app_secret',
                        'required' => true
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Form Türü'),
                        'name' => 'payment_vepara_form_turu',
                        'required' => true,
                        'options' => array(
                            'query' => array(
                                array(
                                    'id_option' => '1',
                                    'name' => 'Ödeme Formu'
                                ),
                            ),
                            'id' => 'id_option',
                            'name' => 'name'
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('3D Secure Option'),
                        'name' => 'payment_vepara_3d_option',
                        'required' => true,
                        'options' => array(
                            'query' => array(
                                array(
                                    'id_option' => '3d',
                                    'name' => '3D Payment'
                                ),
                            ),
                            'id' => 'id_option',
                            'name' => 'name'
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Test / Prod Mode'),
                        'name' => 'payment_vepara_env',
                        'required' => true,
                        'options' => array(
                            'query' => array(
                                array(
                                    'id_option' => 'test',
                                    'name' => 'Test'
                                ),
                                array(
                                    'id_option' => 'prod',
                                    'name' => 'Prod'
                                ),
                            ),
                            'id' => 'id_option',
                            'name' => 'name'
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Debug Mode'),
                        'name' => 'payment_vepara_debug',
                        'required' => true,
                        'options' => array(
                            'query' => array(
                                array(
                                    'id_option' => 1,
                                    'name' => 'Enable'
                                ),
                                array(
                                    'id_option' => 0,
                                    'name' => 'Disable'
                                ),
                            ),
                            'id' => 'id_option',
                            'name' => 'name'
                        ),
                    )
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $this->fields_form = array();
        $helper->id = (int) Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmit';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        
        return $helper->generateForm(array($fields_form));
    }


    /*
     * Admin Panelindeki Yönetici Ayarlarını Çeker
     */
    public function getConfigFieldsValues()
    {

        return array(
            'payment_vepara_merchant_id' => Tools::getValue('payment_vepara_merchant_id', Configuration::get('payment_vepara_merchant_id')),
            'payment_vepara_merchant_key' => Tools::getValue('payment_vepara_merchant_key', Configuration::get('payment_vepara_merchant_key')),
            'payment_vepara_app_key' => Tools::getValue('payment_vepara_app_key', Configuration::get('payment_vepara_app_key')),
            'payment_vepara_app_secret' => Tools::getValue('payment_vepara_app_secret', Configuration::get('payment_vepara_app_secret')),
            'payment_vepara_3d_option' => Tools::getValue('payment_vepara_3d_option', Configuration::get('payment_vepara_3d_option')),
            'payment_vepara_env' => Tools::getValue('payment_vepara_env', Configuration::get('payment_vepara_env')),
            'payment_vepara_debug' => Tools::getValue('payment_vepara_debug', Configuration::get('payment_vepara_debug')),
            'payment_vepara_form_turu' => Tools::getValue('payment_vepara_form_turu', Configuration::get('payment_vepara_form_turu')),
        );
    }


    public function install()
    {
        require_once dirname(__FILE__) . "/sqls.php";
        foreach ($install_sqls as $install_sql){
            $install_sql = str_replace("`ps_", "`" . _DB_PREFIX_, $install_sql);
            try {
                DB::getInstance()->execute($install_sql);
            }catch (exception $e){
                $this->_errors[] = get_class($e).': '.$e->getMessage();
                //$this->uninstall();
                return false;
            }
        }


        if (
            !parent::install()
            || !$this->registerHook('paymentOptions')
            //|| !$this->registerHook('paymentReturn')
        ) {
            return false;
        }
        return true;
    }
       


    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        if (!$this->checkCurrency($params['cart'])) {
            return;
        }

        $payment_options = [
            $this->getPaymentOption(),
        ];

        return $payment_options;
    }

    public function getPaymentOption()
    {
        $returnUrl = $this->context->link->getModuleLink($this->name, 'payment', array(), true);
        $iframeOption = new PaymentOption();
        $iframeOption->setCallToActionText($this->l('Pay With Vepara'))
                     ->setAction($returnUrl)
                     ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/payment.jpg'));

        return $iframeOption;
    }

    private function setcookieSameSite($name, $value, $expire, $path, $domain, $secure, $httponly) {

        if (PHP_VERSION_ID < 70300) {

            setcookie($name, $value, $expire, "$path; samesite=None", $domain, $secure, $httponly);
        }
        else {
            setcookie($name, $value, [
                'expires' => $expire,
                'path' => $path,
                'domain' => $domain,
                'samesite' => 'None',
                'secure' => $secure,
                'httponly' => $httponly
            ]);


        }
    }

    private function checkAndSetCookieSameSite(){

        $checkCookieNames = array('PHPSESSID','OCSESSID','default','PrestaShop-','wp_woocommerce_session_');

        foreach ($_COOKIE as $cookieName => $value) {
            foreach ($checkCookieNames as $checkCookieName){
                if (stripos($cookieName,$checkCookieName) === 0) {
                    $this->setcookieSameSite($cookieName,$_COOKIE[$cookieName], time() + 86400, "/", $_SERVER['SERVER_NAME'],true, true);
                }
            }
        }
    }

}
