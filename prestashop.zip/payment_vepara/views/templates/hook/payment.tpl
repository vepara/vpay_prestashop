

<div class="row">
	<div class="col-xs-12 col-md-6">
	<p class="payment_module">
		<a class="bankwire" style="background: url({$this_path}mini-visa.png) 15px 12px no-repeat #fbfbfb;" href="{$vepara_payment_link}"  title="{l s='Kredi Karti ile Odeme' mod='payment_vepara'}">
			{l s='Kredi Karti ile Odeme' mod='payment_vepara'}&nbsp;
		</a>
	</p>
</div>
</div>

