{extends "$layout"}

{block name="content"}

  <section>
        <div class="alert alert-danger" id="custom-text">
            {$error_message}
        </div>
  </section>


{/block}