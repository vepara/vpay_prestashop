<?php

$install_sqls[] =  "CREATE TABLE IF NOT EXISTS `ps_vepara_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `operation` varchar(255) DEFAULT NULL,
  `transactionId` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `purchase_url` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;";

$uninstall_sqls[] = "";