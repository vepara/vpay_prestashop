<?php
    require_once dirname(__FILE__) . '/../../classes/Transaction.php';

    /**
     * @since 1.5.0
     */
    class payment_veparavalidationModuleFrontController extends ModuleFrontController
    {
        /**
         * @see FrontController::postProcess()
         */
        public function postProcess()
        {

            $cart = $this->context->cart;


            if ($_REQUEST['payment_status']==0) {

                $this->context->smarty->assign([
                    'error_message' => $_REQUEST['error'],
                ]);
                $this->setTemplate('module:payment_vepara/views/templates/front/payment_return.tpl');
                return;

            }


            $secret_key = Configuration::get('payment_vepara_app_secret');


            $sonuc = $this->validateHashKey($_REQUEST['hash_key'], $secret_key);


            if ($sonuc['0'] == $_REQUEST['payment_status'] && $sonuc['2'] == $_REQUEST['invoice_id'] && $sonuc['3'] == $_REQUEST['order_id'] && $_REQUEST['payment_status'] == 1) {
                $success = 1;
            } else {
                exit;
            }


            $customer = new Customer($this->context->customer->id);
            if (!Validate::isLoadedObject($customer))
                Tools::redirect('index.php?controller=order&step=1');
            $currency = $this->context->currency;
            $total = (float)$cart->getOrderTotal(true, Cart::BOTH);
            $mailVars = array();

            $customer_secure_key = false;
            if ($customer and $customer->secure_key)
                $customer_secure_key = $customer->secure_key;


            $this->module->validateOrder($cart->id, Configuration::get('PS_OS_PAYMENT'), $total, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer_secure_key);
            Tools::redirect('index.php?controller=order-confirmation&id_cart=' . $cart->id . '&id_module=' . $this->module->id . '&id_order=' . $this->module->currentOrder . '&key=' . $customer_secure_key);

            return;


            $authorized = false;
            foreach (Module::getPaymentModules() as $module) {
                if ($module['name'] == 'payment_vepara') {
                    $authorized = true;
                    break;
                }
            }

            if (!$authorized) {
                die($this->module->l('This payment method is not available.', 'validation'));
            }

            if (Tools::getValue('RESPONSE_CODE') != '2') {
                var_dump([$_POST, $_GET]);
                $this->context->smarty->assign([
                    'error_message' => Tools::getValue('RESPONSE_DATA'),
                ]);
                $this->setTemplate('payment_return.tpl');
            } else {

                //$hashtr = Tools::getValue('MERCHANT_NO') . Tools::getValue('REFERENCE_CODE') . Tools::getValue('AUTH_CODE') . Tools::getValue('RESPONSE_CODE') . Tools::getValue('USE_3D') . Tools::getValue('RND') . Tools::getValue('INSTALLMENT') . Tools::getValue('AUTHORIZATION_AMOUNT') . Configuration::get('payment_vepara_merchant_secret_key');


                $hashtr['MERCHANT_NO'] = Tools::getValue('MERCHANT_NO');
                $hashtr['REFERENCE_CODE'] = Tools::getValue('REFERENCE_CODE');
                $hashtr['AUTH_CODE'] = Tools::getValue('AUTH_CODE');
                $hashtr['RESPONSE_CODE'] = Tools::getValue('RESPONSE_CODE');
                $hashtr['USE_3D'] = Tools::getValue('USE_3D');
                $hashtr['RND'] = Tools::getValue('RND');
                $hashtr['INSTALLMENT'] = Tools::getValue('INSTALLMENT');
                $hashtr['AUTHORIZATION_AMOUNT'] = Tools::getValue('AUTHORIZATION_AMOUNT');
                $hashtr['payment_vepara_merchant_secret_key'] = Configuration::get('payment_vepara_merchant_secret_key');
                $implode = implode('', $hashtr);
                $hashDatauretilen = base64_encode(pack('H*', sha1($implode)));

                /* HASH CTRL
                echo "<pre>";
                var_dump([
                    'POSTDATA' => $_POST,
                    'HASHLIST' => $hashtr,
                    'IMPLODED' => $implode,
                    'HASHED' => $hashDatauretilen,
                    'YOUR-HASHED' => Tools::getValue('hashData'),
                    'COMPARE' => Tools::getValue('hashData') == $hashDatauretilen
                ]);
                echo "</pre>";
                exit;
                */

                if (Tools::getValue('hashData') != $hashDatauretilen) {
                    $this->context->smarty->assign([
                        'error_message' => 'Hash doğrulaması başarısız',
                    ]);
                    $this->setTemplate('payment_return.tpl');
                    return;
                }

                //CompletePayment
                $vepara = new vepara(
                    Configuration::get('payment_vepara_sx_key'),
                    Configuration::get('payment_vepara_merchant_secret_key'),
                    Configuration::get('payment_vepara_env'),
                    Configuration::get('payment_vepara_debug')
                );
                //$vepara->debug = true;


                if (Tools::getValue('USE_3D') == 'true') {
                    $confirmPaymentAction = $vepara->completePayment(Tools::getValue('REFERENCE_CODE'));

                    if ($confirmPaymentAction['status'] != 'success') {


                        $this->context->smarty->assign([
                            'error_message' => $confirmPaymentAction['message'],
                        ]);
                        $this->setTemplate('module:payment_vepara/views/templates/front/payment_return.tpl');
                        return;
                    }
                }


                $customer = new Customer($this->context->customer->id);
                if (!Validate::isLoadedObject($customer))
                    Tools::redirect('index.php?controller=order&step=1');
                $currency = $this->context->currency;
                $total = (float)$cart->getOrderTotal(true, Cart::BOTH);
                $mailVars = array();

                $customer_secure_key = false;
                if ($customer and $customer->secure_key)
                    $customer_secure_key = $customer->secure_key;


                $this->module->validateOrder($cart->id, Configuration::get('PS_OS_PAYMENT'), $total, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer_secure_key);
                Tools::redirect('index.php?controller=order-confirmation&id_cart=' . $cart->id . '&id_module=' . $this->module->id . '&id_order=' . $this->module->currentOrder . '&key=' . $customer_secure_key);

                return;
            }
        }


        public function curl($payload, $url, $token = "")
        {

            if (!empty($token)) {
                $header = [
                    "Authorization: Bearer $token", "Accept: application/json", "Content-Type: application/json"
                ];
            } else {
                $header = ["Accept: application/json", "Content-Type: application/json"];
            }

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, array());
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            $output = curl_exec($ch);
            curl_close($ch);

            return $output;
        }

        public function generateHash($total, $installment, $currency_code, $merchant_key, $invoice_id, $app_secret)
        {

            $data = $total . '|' . $installment . '|' . $currency_code . '|' . $merchant_key . '|' . $invoice_id;
            $iv = substr(sha1(mt_rand()), 0, 16);
            $password = sha1($app_secret);
            $salt = substr(sha1(mt_rand()), 0, 4);
            $saltWithPassword = hash('sha256', $password . $salt);
            $encrypted = openssl_encrypt("$data", 'aes-256-cbc', "$saltWithPassword", null, $iv);
            $msg_encrypted_bundle = "$iv:$salt:$encrypted";
            $msg_encrypted_bundle = str_replace('/', '__', $msg_encrypted_bundle);
            return $msg_encrypted_bundle;
        }

        public function generateHashComplete($merchant_key, $invoice_id, $order_id, $status, $app_secret)
        {
            $data = $merchant_key . '|' . $invoice_id . '|' . $order_id . '|' . $status;
            $iv = substr(sha1(mt_rand()), 0, 16);
            $password = sha1($app_secret);

            $salt = substr(sha1(mt_rand()), 0, 4);
            $saltWithPassword = hash('sha256', $password . $salt);

            $encrypted = openssl_encrypt(
                "$data", 'aes-256-cbc', "$saltWithPassword", null, $iv
            );
            $msg_encrypted_bundle = "$iv:$salt:$encrypted";
            $msg_encrypted_bundle = str_replace('/', '__', $msg_encrypted_bundle);
            return $msg_encrypted_bundle;
        }

        function validateHashKey($hashKey, $secretKey)
        {

            $status = $currencyCode = "";
            $total = $invoiceId = $orderId = 0;
            if (!empty($hashKey)) {
                $hashkey = str_replace('__', '/', $hashKey);
                $password = sha1($secretKey);
                $components = explode(':', $hashkey);
                if (count($components) > 2) {
                    $iv = isset($components[0]) ? $components[0] : "";
                    $salt = isset($components[1]) ? $components[1] : "";
                    $salt = hash('sha256', $password . $salt);
                    $encryptedMsg = isset($components[2]) ? $components[2] : "";
                    $decryptedMsg = openssl_decrypt($encryptedMsg, 'aes-256-cbc', $salt, null, $iv);
                    if (strpos($decryptedMsg, '|') !== false) {
                        $array = explode('|', $decryptedMsg);
                        $status = isset($array[0]) ? $array[0] : 0;
                        $total = isset($array[1]) ? $array[1] : 0;
                        $invoiceId = isset($array[2]) ? $array[2] : '0';
                        $orderId = isset($array[3]) ? $array[3] : 0;
                        $currencyCode = isset($array[4]) ? $array[4] : '';
                    }
                    return [$status, $total, $invoiceId, $orderId, $currencyCode];
                }
            }
        }

        public function getIp()
        {
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            return $ip;
        }

        public function amountTemizle($amount)
        {
            $amount = trim($amount);
            $amount = str_replace(".0000", "", $amount);
            $amount = str_replace(".00", "", $amount);
            return $amount;
        }

    }
