<?php



/**
 * @since 1.5.0
 */
require_once dirname(__FILE__) . '/../../classes/Vepara.php';
require_once dirname(__FILE__) . '/../../classes/Transaction.php';

class payment_veparaPaymentModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {

        parent::initContent();
        $currency = new Currency($this->context->cart->id_currency);
        $cart = $this->context->cart;


        if (!$this->module->checkCurrency($cart))
            Tools::redirect('index.php?controller=order');

        if($this->context->cart->getOrderTotal()==0){
            Tools::redirect('index.php?controller=order');
        }

        $this->context->controller->addJquery();


        $order_info                     = $this->context->cart;
        $customer                       = new Customer(intval($order_info->id_customer));
        $address                        = new Address(intval($order_info->id_address_invoice));
        $country                        = new Country(intval($address->id_country));
        $cart_products                  = $order_info->getProducts();
        $items                          = [];


        $site_url = explode("module", $_SERVER['REQUEST_URI'])[0];


        $form['site_url'] = $site_url;
        $form['order_id'] = $this->context->cart->id;
        $form['payment_vepara_form_turu'] = Configuration::get('payment_vepara_form_turu');
        $form['amount'] = number_format($this->context->cart->getOrderTotal(), 2, '.', '');
        $form['url'] = vepara::$urls['checkout'][ Configuration::get('payment_vepara_env') ];
        $form['params'] = [
            'api_key' => Configuration::get('payment_vepara_api_key'),
            'api_secret' => Configuration::get('payment_vepara_api_secret'),
            'successUrl' => $this->context->link->getModuleLink($this->module->name, 'validation', [], 1),
            'failUrl' => $this->context->link->getModuleLink($this->module->name, 'validation', [], 1),
            'amount' => number_format($this->context->cart->getOrderTotal(), 2, '.', ''),
            'second' => "",
            'cardcampaign' => "",
            'bin' => "",
            'language' => "",//strtoupper($this->context->language->iso_code),
            'cardControl' => "",
            'nameSurname' => "",
            'rnd' => Date('d-m-Y H:i') .'000'. rand(10,99),
            'transactionType' => 'SALES',
        ];


        if(isset($_REQUEST['error'])){
            $this->context->controller->errors[] = $this->module->l(base64_decode($_REQUEST['error'])); // Replace 'Error message' with your own error message

        }



        $this->context->smarty->assign([
            'nform' => $form,
        ]);
        $this->setTemplate('module:payment_vepara/views/templates/front/payment_form.tpl');
        return;
    }

    public function generateHash($apiKey, $apiSecret, $random, $dataToEncrypt)
    {
        $computedHashAsHex = hash_hmac('SHA256', $dataToEncrypt, utf8_encode($apiSecret));
        $authorizationString = sprintf("APIKey:%s&Random:%s&Signature:%s", $apiKey, $random, $computedHashAsHex);
        $result = base64_encode($authorizationString);
        return $result;
    }
}
