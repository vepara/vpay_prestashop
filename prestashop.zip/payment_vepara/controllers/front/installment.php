<?php
    require_once dirname(__FILE__) . '/../../classes/Vepara.php';

    /**
     * @since 1.5.0
     */
    class payment_veparainstallmentModuleFrontController extends ModuleFrontController
    {
        /**
         * @see FrontController::postProcess()
         */
        public function postProcess()
        {



            $status = Configuration::get('payment_vepara_env');
            if ($status == "test") {

                $url = "https://test.vepara.com.tr/ccpayment/api/getpos";
                $url_token = "https://test.vepara.com.tr/ccpayment/api/token";
            } else {
                $url = "https://app.vepara.com.tr/ccpayment/api/getpos";
                $url_token = "https://app.vepara.com.tr/ccpayment/api/token";
            }


            $api_key = Configuration::get('payment_vepara_app_key');
            $api_secret = Configuration::get('payment_vepara_app_secret');
            $amount = number_format($this->context->cart->getOrderTotal(), 2, '.', '');


            $token = $this->getToken($api_key, $api_secret, $url_token);

            $par = [
                'merchant_key' => Configuration::get('payment_vepara_merchant_key'),
                'amount' => $amount,
                'credit_card' => trim($_REQUEST['cardnumber']),
                'currency_code' => "TRY",
            ];

            $installament = json_decode($this->curl($par, $url, $token));


            if ($installament->status_code == 100) {

                $html = '<div class="col wid100" id="tlist">';
                $html .= '<table class="table border rounded bg-white">';
                $html .= '<tbody>';


                foreach ($installament->data as $key => $taksitler) {

                    if ($taksitler->installments_number == 1) {
                        $text_value = "Tek Çekim";
                    } else {
                        $text_value = $taksitler->installments_number . " x " . $taksitler->payable_amount;
                    }
                    $total = $taksitler->amount_to_be_paid;
                    if (empty(explode(".", $total)[1])) {
                        $total = $total . ".00";
                    } else {
                        if (strlen(explode(".", $total)[1]) == 1) {
                            $total = $total . "0";
                        }
                    }

                    $html .= '<tr><td class="px-3 py-2"><div class="form-check">';
                    $html .= '<input type="radio" data-sayi="' . $taksitler->installments_number . '" id="tno' . $taksitler->installments_number . '" ';
                    $html .= 'onclick="updateSubmitButtonAmount(\'' . $total . '\')" class="form-check-input p-1" name="tno"';
                    if ($taksitler->installments_number == 1) {
                        $html .= 'checked';
                    }
                    $html .= 'value="' . $taksitler->installments_number . '"';
                    $html .= 'tag="' . $total . '"';
                    $html .= '<label class="form-check-label" for="tno' . $taksitler->installments_number . '"><strong>' . $text_value . '</strong></label></div></td>';

                    $html .= '<td class="px-3 py-2" id="instalmentTd' . $key . '"><label for="tno1">' . $total . ' ₺ </label></td>';
                    $html .= '<td class="px-3 py-2 text-primary"><strong></strong></td></tr>';
                    $html .= '<input type="hidden" name="tsx' . $taksitler->installments_number . '" value="' . $taksitler->hash_key . '">';
                }

                $html .= '</tbody></table></div>';

                echo $html;
            } else {
                echo "<h5>Bu karta taksit yapılmamaktadır.</h5>";
            }

            exit;
        }

        public function getToken($api_key, $api_secret, $url_token)
        {
            $par = [
                'app_id' => $api_key,
                'app_secret' => $api_secret,
            ];


            $token_result = json_decode($this->curl($par, $url_token));

            if ($token_result->status_code == 100) {
                $token = $token_result->data->token;
            }

            return $token;
        }

        public function curl($payload, $url, $token = "")
        {

            if (!empty($token)) {
                $header = [
                    "Authorization: Bearer $token", "Accept: application/json", "Content-Type: application/json"
                ];
            } else {
                $header = ["Accept: application/json", "Content-Type: application/json"];
            }

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, array());
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            $output = curl_exec($ch);
            curl_close($ch);



            return $output;
        }

        public function generateHash($total, $installment, $currency_code, $merchant_key, $invoice_id, $app_secret)
        {

            $data = $total . '|' . $installment . '|' . $currency_code . '|' . $merchant_key . '|' . $invoice_id;
            $iv = substr(sha1(mt_rand()), 0, 16);
            $password = sha1($app_secret);
            $salt = substr(sha1(mt_rand()), 0, 4);
            $saltWithPassword = hash('sha256', $password . $salt);
            $encrypted = openssl_encrypt("$data", 'aes-256-cbc', "$saltWithPassword", null, $iv);
            $msg_encrypted_bundle = "$iv:$salt:$encrypted";
            $msg_encrypted_bundle = str_replace('/', '__', $msg_encrypted_bundle);
            return $msg_encrypted_bundle;
        }

        public function generateHashComplete($merchant_key, $invoice_id, $order_id, $status, $app_secret)
        {
            $data = $merchant_key . '|' . $invoice_id . '|' . $order_id . '|' . $status;
            $iv = substr(sha1(mt_rand()), 0, 16);
            $password = sha1($app_secret);

            $salt = substr(sha1(mt_rand()), 0, 4);
            $saltWithPassword = hash('sha256', $password . $salt);

            $encrypted = openssl_encrypt(
                "$data", 'aes-256-cbc', "$saltWithPassword", null, $iv
            );
            $msg_encrypted_bundle = "$iv:$salt:$encrypted";
            $msg_encrypted_bundle = str_replace('/', '__', $msg_encrypted_bundle);
            return $msg_encrypted_bundle;
        }

        function validateHashKey($hashKey)
        {
            $secretKey = get_option("woocommerce_vepara_settings")['app_secret'];

            $status = $currencyCode = "";
            $total = $invoiceId = $orderId = 0;
            if (!empty($hashKey)) {
                $hashkey = str_replace('__', '/', $hashKey);
                $password = sha1($secretKey);
                $components = explode(':', $hashkey);
                if (count($components) > 2) {
                    $iv = isset($components[0]) ? $components[0] : "";
                    $salt = isset($components[1]) ? $components[1] : "";
                    $salt = hash('sha256', $password . $salt);
                    $encryptedMsg = isset($components[2]) ? $components[2] : "";
                    $decryptedMsg = openssl_decrypt($encryptedMsg, 'aes-256-cbc', $salt, null, $iv);
                    if (strpos($decryptedMsg, '|') !== false) {
                        $array = explode('|', $decryptedMsg);
                        $status = isset($array[0]) ? $array[0] : 0;
                        $total = isset($array[1]) ? $array[1] : 0;
                        $invoiceId = isset($array[2]) ? $array[2] : '0';
                        $orderId = isset($array[3]) ? $array[3] : 0;
                        $currencyCode = isset($array[4]) ? $array[4] : '';
                    }
                    return [$status, $total, $invoiceId, $orderId, $currencyCode];
                }
            }
        }

        public function getIp()
        {
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            return $ip;
        }

        public function amountTemizle($amount)
        {
            $amount = trim($amount);
            $amount = str_replace(".0000", "", $amount);
            $amount = str_replace(".00", "", $amount);
            return $amount;
        }

    }
