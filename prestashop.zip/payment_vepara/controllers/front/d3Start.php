<?php
    require_once dirname(__FILE__) . '/../../classes/Vepara.php';

    ini_set('display_startup_errors', 1);
    ini_set('display_errors', 1);
    error_reporting(-1);


    /**
     * @since 1.5.0
     */
    class payment_veparad3StartModuleFrontController extends ModuleFrontController
    {
        /**
         * @see FrontController::postProcess()
         */
        public function postProcess()
        {

            if(!isset($_REQUEST['order_id'])){
                exit;
            }


            $status = Configuration::get('payment_vepara_env');
            if ($status == "test") {
                $url = "https://test.vepara.com.tr/ccpayment/api/paySmart3D";
            } else {
                $url = "https://app.vepara.com.tr/ccpayment/api/paySmart3D";

            }


            $order_id = $_REQUEST['order_id'];
            $api_key = Configuration::get('payment_vepara_app_key');
            $api_secret = Configuration::get('payment_vepara_app_secret');
            $merchant_key = Configuration::get('payment_vepara_merchant_key');

            $okUrl = $this->context->link->getModuleLink($this->module->name, 'validation', [], 1);
            $amount = floatval($this->amountTemizle($_REQUEST['odenecek_tutar']));


            /*
             * Siparişteki ürünleri listeler
             */


            $cart = $this->context->cart;
            $address = new Address($this->context->cart->id_address_delivery);
            $state = new State ($address->id_state);
            $country = new Country ($address->id_country);
            $customer = new Customer($this->context->customer->id);


            $items = [];

            $products = $this->context->cart->getProducts(true);
            foreach ($products as $product) {
                $items[] = array(
                    'price' => $product['price'],
                    'name' => $product['name'],
                    'quantity' => intval($product['cart_quantity']),
                    'description' => $product['name'] . " ürünü"
                );
            }


            $items = json_encode($items);


            $hash_key = $this->generateHash($amount, $_REQUEST['secilen_taksit'], "TRY", $merchant_key, $order_id, $api_secret);

            $cart = $this->context->cart;
            $customer = new Customer($cart->id_customer);
            $addresses = $customer->getAddresses($this->context->language->id);

            if (!empty($addresses)) {
                $phoneNumber = $addresses[0]['phone'];
            }else {
                $phoneNumber = "0545";
            }


            $vars = [
                'cc_holder_name' => $_REQUEST['cardHolderName'],
                'cc_no' => str_replace(" ", "", $_REQUEST['cardNumber']),
                'expiry_month' => $_REQUEST['ay'],
                'expiry_year' => $_REQUEST['yil'],
                'cvv' => $_REQUEST['cvv'],
                'currency_code' => "TRY",
                'installments_number' => intval($_REQUEST['secilen_taksit']),
                'invoice_id' => $order_id,
                'invoice_description' => $order_id . " Nolu Sipariş Ödemesi",
                'name' => $customer->firstname,
                'surname' => $customer->lastname,
                'total' => $amount,
                'merchant_key' => $merchant_key,
                'items' => $items,
                'return_url' => (string)$okUrl,
                'cancel_url' => (string)$okUrl,
                'hash_key' => $hash_key,
                'bill_address1' => $address->address1,
                'bill_address2' => $address->address2,
                'bill_city' => "Vakfıkebir",
                'bill_postcode' => $address->postcode,
                'bill_state' => $address->city,
                'bill_country' => "Türkiye",
                'bill_email' => $customer->email,
                'bill_phone' => $phoneNumber,
                'ip' => $this->getIp(),
                'transaction_type' => "Auth",
                'sale_webhook_key' => $order_id,
                'payment_completed_by' => "app",
                'response_method' => "POST",
            ];



            ?>

            <style>
                /* Absolute Center Spinner */
                .loading {
                    position: fixed;
                    z-index: 999;
                    height: 2em;
                    width: 2em;
                    overflow: visible;
                    margin: auto;
                    top: 0;
                    left: 0;
                    bottom: 0;
                    right: 0;
                }

                /* Transparent Overlay */
                .loading:before {
                    content: '';
                    display: block;
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0, 0, 0, 0.3);
                }

                /* :not(:required) hides these rules from IE9 and below */
                .loading:not(:required) {
                    /* hide "loading..." text */
                    font: 0/0 a;
                    color: transparent;
                    text-shadow: none;
                    background-color: transparent;
                    border: 0;
                }

                .loading:not(:required):after {
                    content: '';
                    display: block;
                    font-size: 10px;
                    width: 1em;
                    height: 1em;
                    margin-top: -0.5em;
                    -webkit-animation: spinner 1500ms infinite linear;
                    -moz-animation: spinner 1500ms infinite linear;
                    -ms-animation: spinner 1500ms infinite linear;
                    -o-animation: spinner 1500ms infinite linear;
                    animation: spinner 1500ms infinite linear;
                    border-radius: 0.5em;
                    -webkit-box-shadow: rgba(0, 0, 0, 0.75) 1.5em 0 0 0, rgba(0, 0, 0, 0.75) 1.1em 1.1em 0 0, rgba(0, 0, 0, 0.75) 0 1.5em 0 0, rgba(0, 0, 0, 0.75) -1.1em 1.1em 0 0, rgba(0, 0, 0, 0.5) -1.5em 0 0 0, rgba(0, 0, 0, 0.5) -1.1em -1.1em 0 0, rgba(0, 0, 0, 0.75) 0 -1.5em 0 0, rgba(0, 0, 0, 0.75) 1.1em -1.1em 0 0;
                    box-shadow: rgba(0, 0, 0, 0.75) 1.5em 0 0 0, rgba(0, 0, 0, 0.75) 1.1em 1.1em 0 0, rgba(0, 0, 0, 0.75) 0 1.5em 0 0, rgba(0, 0, 0, 0.75) -1.1em 1.1em 0 0, rgba(0, 0, 0, 0.75) -1.5em 0 0 0, rgba(0, 0, 0, 0.75) -1.1em -1.1em 0 0, rgba(0, 0, 0, 0.75) 0 -1.5em 0 0, rgba(0, 0, 0, 0.75) 1.1em -1.1em 0 0;
                }

                /* Animation */

                @-webkit-keyframes spinner {
                    0% {
                        -webkit-transform: rotate(0deg);
                        -moz-transform: rotate(0deg);
                        -ms-transform: rotate(0deg);
                        -o-transform: rotate(0deg);
                        transform: rotate(0deg);
                    }
                    100% {
                        -webkit-transform: rotate(360deg);
                        -moz-transform: rotate(360deg);
                        -ms-transform: rotate(360deg);
                        -o-transform: rotate(360deg);
                        transform: rotate(360deg);
                    }
                }

                @-moz-keyframes spinner {
                    0% {
                        -webkit-transform: rotate(0deg);
                        -moz-transform: rotate(0deg);
                        -ms-transform: rotate(0deg);
                        -o-transform: rotate(0deg);
                        transform: rotate(0deg);
                    }
                    100% {
                        -webkit-transform: rotate(360deg);
                        -moz-transform: rotate(360deg);
                        -ms-transform: rotate(360deg);
                        -o-transform: rotate(360deg);
                        transform: rotate(360deg);
                    }
                }

                @-o-keyframes spinner {
                    0% {
                        -webkit-transform: rotate(0deg);
                        -moz-transform: rotate(0deg);
                        -ms-transform: rotate(0deg);
                        -o-transform: rotate(0deg);
                        transform: rotate(0deg);
                    }
                    100% {
                        -webkit-transform: rotate(360deg);
                        -moz-transform: rotate(360deg);
                        -ms-transform: rotate(360deg);
                        -o-transform: rotate(360deg);
                        transform: rotate(360deg);
                    }
                }

                @keyframes spinner {
                    0% {
                        -webkit-transform: rotate(0deg);
                        -moz-transform: rotate(0deg);
                        -ms-transform: rotate(0deg);
                        -o-transform: rotate(0deg);
                        transform: rotate(0deg);
                    }
                    100% {
                        -webkit-transform: rotate(360deg);
                        -moz-transform: rotate(360deg);
                        -ms-transform: rotate(360deg);
                        -o-transform: rotate(360deg);
                        transform: rotate(360deg);
                    }
                }
            </style>
            <div class="loading">Loading&#8230;</div>
            <form action="<?php echo $url ?>" method="post"><?php
                    foreach ($vars as $key => $value) { ?>
                        <input type="hidden" name="<?php echo $key ?>" value='<?php echo $value ?>'>
                <?php
                    }
                ?>
                <input type="submit" value="GÖNDER" id="devam" style="display: none">
            </form>

            <script>
                document.getElementById("devam").click();
            </script><?php


            exit;

        }

        public function curl($payload, $url, $token = "")
        {

            if (!empty($token)) {
                $header = [
                    "Authorization: Bearer $token", "Accept: application/json", "Content-Type: application/json"
                ];
            } else {
                $header = ["Accept: application/json", "Content-Type: application/json"];
            }

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, array());
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            $output = curl_exec($ch);
            curl_close($ch);

            return $output;
        }

        public function generateHash($total, $installment, $currency_code, $merchant_key, $invoice_id, $app_secret)
        {

            $data = $total.'|'.$installment.'|'.$currency_code.'|'.$merchant_key.'|'.$invoice_id;
            $iv = substr(sha1(mt_rand()), 0, 16);
            $password = sha1($app_secret);
            $salt = substr(sha1(mt_rand()), 0, 4);
            $saltWithPassword = hash('sha256', $password . $salt);
            $encrypted = openssl_encrypt("$data", 'aes-256-cbc', "$saltWithPassword", null, $iv);
            $msg_encrypted_bundle = "$iv:$salt:$encrypted";
            $msg_encrypted_bundle = str_replace('/', '__', $msg_encrypted_bundle);
            return $msg_encrypted_bundle;
        }

        public function generateHashComplete($merchant_key, $invoice_id, $order_id, $status, $app_secret)
        {
            $data = $merchant_key . '|' . $invoice_id . '|' . $order_id . '|' . $status;
            $iv = substr(sha1(mt_rand()), 0, 16);
            $password = sha1($app_secret);

            $salt = substr(sha1(mt_rand()), 0, 4);
            $saltWithPassword = hash('sha256', $password . $salt);

            $encrypted = openssl_encrypt(
                "$data", 'aes-256-cbc', "$saltWithPassword", null, $iv
            );
            $msg_encrypted_bundle = "$iv:$salt:$encrypted";
            $msg_encrypted_bundle = str_replace('/', '__', $msg_encrypted_bundle);
            return $msg_encrypted_bundle;
        }

        function validateHashKey($hashKey)
        {
            $secretKey = get_option("woocommerce_vepara_settings")['app_secret'];

            $status = $currencyCode = "";
            $total = $invoiceId = $orderId = 0;
            if (!empty($hashKey)) {
                $hashkey = str_replace('__', '/', $hashKey);
                $password = sha1($secretKey);
                $components = explode(':', $hashkey);
                if (count($components) > 2) {
                    $iv = isset($components[0]) ? $components[0] : "";
                    $salt = isset($components[1]) ? $components[1] : "";
                    $salt = hash('sha256', $password . $salt);
                    $encryptedMsg = isset($components[2]) ? $components[2] : "";
                    $decryptedMsg = openssl_decrypt($encryptedMsg, 'aes-256-cbc', $salt, null, $iv);
                    if (strpos($decryptedMsg, '|') !== false) {
                        $array = explode('|', $decryptedMsg);
                        $status = isset($array[0]) ? $array[0] : 0;
                        $total = isset($array[1]) ? $array[1] : 0;
                        $invoiceId = isset($array[2]) ? $array[2] : '0';
                        $orderId = isset($array[3]) ? $array[3] : 0;
                        $currencyCode = isset($array[4]) ? $array[4] : '';
                    }
                    return [$status, $total, $invoiceId, $orderId, $currencyCode];
                }
            }
        }

        public function getIp()
        {
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            return $ip;
        }

        public function amountTemizle($amount)
        {
            $amount = trim($amount);
            $amount = str_replace(".0000", "", $amount);
            $amount = str_replace(".00", "", $amount);
            return $amount;
        }

    }
